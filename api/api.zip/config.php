<?php
    define('HOST', 'localhost');
    define('USER', 'root');
    define('PASS', '');
    define('DB', 'rs_bhayangkara_db');

    $img_berita = 'http://192.168.56.1/rs_bhayangkara/gambar_berita/';

    $con = mysqli_connect(HOST, USER, PASS, DB);
?>
